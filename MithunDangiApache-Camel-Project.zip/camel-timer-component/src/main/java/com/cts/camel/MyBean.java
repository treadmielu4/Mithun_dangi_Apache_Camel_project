package com.cts.camel;

public class MyBean {
public void sayHello(String message) {
	System.out.println("My Bean sayHello() :"+message);
}
}
