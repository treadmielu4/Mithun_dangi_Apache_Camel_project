package com.cts.camel;

public class MyRouteBuilder {

}
