package com.cts.camel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CamelSpring2Application {

	public static void main(String[] args) {
		SpringApplication.run(CamelSpring2Application.class, args);
	}

}
