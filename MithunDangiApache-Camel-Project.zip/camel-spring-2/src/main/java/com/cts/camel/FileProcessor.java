package com.cts.camel;

public class FileProcessor {

}
