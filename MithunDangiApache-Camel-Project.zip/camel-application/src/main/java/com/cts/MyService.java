package com.cts;

public class MyService {

	public void display(String message) {
		System.out.println(message);
	}
}
